package com.invenco.utilities;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TimeDifference extends VariablesUsed {

	// @Test
	public static String timeDiff() throws ParseException {

		SimpleDateFormat dateFormat = new SimpleDateFormat(
				"yyyy-MM-dd HH:mm:sss");
		String date_s = oldDate;
		Date old = dateFormat.parse(date_s);
		// System.out.println("old time"+old.getTime());

		Date now = new Date();
		// System.out.println("new time"+now.getTime());
		long diff = (now.getTime() - old.getTime());
		// System.out.println("diff in sec"+diff/1000);
		// System.out.println("diff in min"+diff/60000);
		// System.out.println("diff in hrs"+diff/3600000);
		long diffInHours = diff / 3600000;
		long diffInDays = diff / 86400000;
		long diffInMonths = diff / (2592000000L);
		String temp = "few minutes ago";
		/*
		 * if (diffInMonths >= 1) { // System.out.println(diffInMonths +
		 * " month(s) ago"); temp = diffInMonths + " month(s) ago";
		 * System.out.println(temp); } else if (diffInDays >= 1) { //
		 * System.out.println(diffInDays + " days ago"); temp = diffInDays +
		 * " days ago"; System.out.println(temp);
		 * 
		 * } else if (diffInHours >= 1) { // System.out.println(diffInHours +
		 * " Hours ago"); temp = diffInHours + " Hours ago";
		 * System.out.println(temp); }
		 */

		//HOURS
		if (diffInHours >= 1 && diffInHours<2) {

			temp = "an hour ago";
			// System.out.println(temp);
		} else if (diffInHours >= 2 && diffInDays < 1 && diffInMonths < 1) {

			temp = diffInHours + " hours ago";
			// System.out.println(temp);
		} 
		
		//DAYS
		else if (diffInDays >= 1 && diffInDays <2) {

			temp = "a Day ago";
			// System.out.println(temp);
		}else if (diffInDays >=2 && diffInMonths < 1) {

			temp = diffInDays + " Days ago";
			// System.out.println(temp);
		} 
		
		//MONTHS
		else if ( diffInMonths >= 1 && diffInMonths < 2) {

			temp = "a Month ago";
			// System.out.println(temp);
		}
		else if (diffInMonths >= 2) {

			temp = diffInDays + " Month ago";
			// System.out.println(temp);
		}

		return temp;

	}

}

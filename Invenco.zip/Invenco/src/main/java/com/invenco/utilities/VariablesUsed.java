package com.invenco.utilities;

public class VariablesUsed {

	public static String username = "user123";
	public static String password = "Password123";
	public static String url = "https://invenco-nz-qa.tms.invenco.com/";
	public static String oldDate="2016-05-30 08:00:00.000";
}

package com.invenco.objectrepo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class KiranTestSite1PageObjects {

	private static WebElement element = null;

	public static WebElement entry_OPT1_43(WebDriver driver) {
		element = driver.findElement(By.xpath(".//*[@id='G6OPT-A130800593']/div/div[4]"));
		return element;
	}
}

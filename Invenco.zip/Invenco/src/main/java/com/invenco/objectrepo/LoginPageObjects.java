package com.invenco.objectrepo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPageObjects {
	private static WebElement element = null;

	public static WebElement txtbx_UserName(WebDriver driver) {
		element = driver.findElement(By.id("username"));
		return element;
	}
	
	public static WebElement txtbx_Password(WebDriver driver) {
		element = driver.findElement(By.id("password"));
		return element;
	}

	public static WebElement button_Login(WebDriver driver) {
		element = driver.findElement(By.xpath(".//*[@id='kc-login']"));
		return element;
	}
}

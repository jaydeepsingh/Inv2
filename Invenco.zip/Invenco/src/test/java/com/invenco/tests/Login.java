package com.invenco.tests;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.invenco.objectrepo.LoginPageObjects;
import com.invenco.utilities.Driver;
import com.invenco.utilities.VariablesUsed;

public class Login extends VariablesUsed {

	@Test
	public static void login() {
		try{
		//Driver.driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Driver.browser("firefox");
		Driver.driver.get(url);
		LoginPageObjects.txtbx_UserName(Driver.driver).sendKeys(username);
		LoginPageObjects.txtbx_Password(Driver.driver).sendKeys(password);
		LoginPageObjects.button_Login(Driver.driver).click();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}

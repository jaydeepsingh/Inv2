package com.invenco.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.invenco.objectrepo.DashboardPageObjects;
import com.invenco.objectrepo.KiranTestSite1PageObjects;
import com.invenco.objectrepo.SitePageObjects;
import com.invenco.utilities.Driver;
import com.invenco.utilities.TimeDifference;

public class OPT1_43_VerifyRules {
	
	
	
	@Test
	public void verify(){
		//
		try{
		Login.login();
		Thread.sleep(3000);
		DashboardPageObjects.link_Sites(Driver.driver).click();
		Thread.sleep(3000);
		SitePageObjects.link_KiranTestsite1(Driver.driver).click();
		Thread.sleep(3000);
		String actual = KiranTestSite1PageObjects.entry_OPT1_43(Driver.driver).getText();
		System.out.println("Actual value from UI- "+actual);
		String expected= TimeDifference.timeDiff();
		System.out.println("Expected value from Business Rule- "+expected);
		Assert.assertEquals(actual.toLowerCase(), expected.toLowerCase());
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

}
